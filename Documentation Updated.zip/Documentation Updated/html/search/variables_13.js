var searchData=
[
  ['version_1958',['Version',['../_debug_2_code_analysis_result_manifest_8txt.html#ab7adfe952841be7b41706147f117f403',1,'Version():&#160;CodeAnalysisResultManifest.txt'],['../_release_2_code_analysis_result_manifest_8txt.html#a517a5ab7f877a7df1e0609b2cef35a42',1,'Version():&#160;CodeAnalysisResultManifest.txt']]]
];

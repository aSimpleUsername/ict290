var searchData=
[
  ['takeammo_1791',['takeAmmo',['../class_weapon.html#acf8b44a9dc40d291cb554291ccf13a23',1,'Weapon']]],
  ['texturedpolygons_1792',['TexturedPolygons',['../class_textured_polygons.html#a2fd288c8e0d4a158c1c36c7474e0a4c2',1,'TexturedPolygons::TexturedPolygons()'],['../class_textured_polygons.html#a22fb5adddf718bcd26d723069d31679a',1,'TexturedPolygons::TexturedPolygons(const TexturedPolygons &amp;tp)']]],
  ['timercallback_1793',['timerCallback',['../main_8cpp.html#ad69f0e16fe1330c6ed1dde52241e4209',1,'main.cpp']]],
  ['transparent_1794',['transparent',['../class_user_interface.html#a986d9732a3b1e2c6f60b7aa684f16a76',1,'UserInterface']]]
];

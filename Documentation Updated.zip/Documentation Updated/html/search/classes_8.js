var searchData=
[
  ['userinterface_1260',['UserInterface',['../class_user_interface.html',1,'']]]
];

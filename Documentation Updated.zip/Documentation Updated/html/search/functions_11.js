var searchData=
[
  ['updatehitbox_1795',['updateHitBox',['../class_enemy.html#ac873066448538ebf477c6de2cb0ac679',1,'Enemy']]],
  ['updatelocation_1796',['updateLocation',['../class_player.html#abf7e3dbd5cfb5f9267dd12193f1a98f0',1,'Player']]]
];

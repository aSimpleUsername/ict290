var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvwxyz~",
  1: "abcdeoptuwx",
  2: "acdefgmopstuw",
  3: "abcdeghiklmnoprstuw~",
  4: "abcdefghiklmnoprstuvwxyz",
  5: "g",
  6: "_abcdefghiklmnprstvwxyz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};


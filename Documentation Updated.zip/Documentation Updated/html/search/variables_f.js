var searchData=
[
  ['radius_1940',['radius',['../class_enemy.html#ada3c1a04b0e59cff45e83c4d86f6d76a',1,'Enemy']]],
  ['ratio_1941',['ratio',['../main_8cpp.html#a207ad05f99cc72068a92358861ff5e71',1,'main.cpp']]]
];

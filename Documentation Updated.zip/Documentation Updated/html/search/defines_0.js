var searchData=
[
  ['_5fuse_5fmath_5fdefines_1978',['_USE_MATH_DEFINES',['../point3_d_8h.html#a525335710b53cb064ca56b936120431e',1,'point3D.h']]]
];

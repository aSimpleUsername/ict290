var searchData=
[
  ['bosshealthbar_1326',['bossHealthBar',['../class_user_interface.html#a99136f82814ce46deef1d531efdb7f27',1,'UserInterface']]],
  ['bossname_1327',['bossName',['../class_user_interface.html#ad6680d4666c9a9ecaa7686c106f8955b',1,'UserInterface']]],
  ['bossportall_1328',['bossPortalL',['../class_display_wrath_world.html#a43feace085b374d4708a261d97d8bb03',1,'DisplayWrathWorld']]],
  ['bossportalr_1329',['bossPortalR',['../class_display_wrath_world.html#aebe9e161c5aea390ab490a7f44ba39c1',1,'DisplayWrathWorld']]]
];

var searchData=
[
  ['netframework_1932',['NETFramework',['../_debug_2_code_analysis_result_manifest_8txt.html#a13d64915e6abe5fbe820c3dfb0e7a06f',1,'NETFramework():&#160;CodeAnalysisResultManifest.txt'],['../_release_2_code_analysis_result_manifest_8txt.html#a18b5624c8dc61688ec7dc270ed2af97f',1,'NETFramework():&#160;CodeAnalysisResultManifest.txt']]],
  ['num_5fenemies_1933',['NUM_ENEMIES',['../class_display_wrath_world.html#a9786ebd6819bcdf0c5f7b6ad8f0ca13b',1,'DisplayWrathWorld']]]
];
